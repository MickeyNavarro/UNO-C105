import java.util.ArrayList;

// Almicke "Mickey" Navarro
// CST105
// Date: Mar 12, 2018
// This is my own work.

public class Player {
	public ArrayList <Card> Hand;
	public String playerName; 

	
	public Player(String name) {
		//make a new arraylist of cards for the player hand
		Hand = new ArrayList<Card>();
		playerName = name;
	}
	
	public String getName() {
		return playerName;
	} 
	
	//adds a card to the player hand
	public void takeCard(Card c) {
		Hand.add(c);
	}
	
	//checks if the card is a match; if match, the card is played
	public Card playCard(Player p, Card c) {
		for (Card cardPlayed : p.Hand) {
			//check if match
			if (cardPlayed.isMatch(c)) {
				//remove card from player hand
				Hand.remove(Hand.indexOf(cardPlayed));
				return cardPlayed; 
			}
		}
		return null;
	}
	
	//checks if player hand has 1 card, or checks for uno
	public boolean uno() {
		if (Hand.size() == 1)
			return true;
		return false;
	}
	
	//check if the hand is empty to determine if they are a winner
	public boolean winner() {
		return Hand.size()==0;
	}
	
	//returns each card in the hand with the card itself and a space to organize output
	public String toString() {
		String str = "";
		for (Card c : Hand) {
			str += c + " ";
		}
		return str; 
	}

}
