// Almicke "Mickey" Navarro
// CST105
// Date: Mar 12, 2018
// This is my own work.

public class Card {
	public String value; 
	public String color;
	
	//create strings of the colors to be easily accessed
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
		
	public Card(String value, String color) {
		this.value = value;
		this.color = color;
	}

	@Override
	public String toString() {
		//return the color with its value, then reset to black so the colors would not overlap
		if (this.value == "WildDrawFour") {
			return ANSI_RED + "W" + ANSI_RESET + ANSI_YELLOW + "i" + ANSI_RESET + ANSI_GREEN + "l" + ANSI_RESET + ANSI_BLUE + "d" + ANSI_RESET + ANSI_RED + "D" + ANSI_RESET + ANSI_YELLOW + "r" + ANSI_RESET + ANSI_GREEN + "a" + ANSI_RESET + ANSI_BLUE + "w" + ANSI_RESET + ANSI_RED + "F" + ANSI_RESET + ANSI_YELLOW + "o" + ANSI_RESET + ANSI_GREEN + "u" + ANSI_RESET + ANSI_BLUE + "r" + ANSI_RESET;
		}
		else if (this.value == "Wild") {
			return ANSI_RED + "W" + ANSI_RESET + ANSI_YELLOW + "i" + ANSI_RESET + ANSI_GREEN + "l" + ANSI_RESET + ANSI_BLUE + "d" + ANSI_RESET;
		}
		else if (this.color == "Red") {
			return ANSI_RED + value + ANSI_RESET;	
		}
		else if (this.color == "Yellow") {
			return ANSI_YELLOW + value + ANSI_RESET;	
		}
		else if (this.color == "Green") {
			return ANSI_GREEN + value + ANSI_RESET;	
		}
		else if (this.color == "Blue") {
			return ANSI_BLUE + value + ANSI_RESET;	
		} 
		else 
			return null; 
	}
	
	public boolean isMatch(Card c) {
		//check if color matches
		if (this.color.equals(c.color))
			return true;
		//check if value matches
		else if (this.value.equals(c.value))
			return true;
		//check if card is wild 
		else if (this.isWild())
			return true;
		//checks if card is wild draw 4
		else if (this.isWildDraw4()) 
			return true; 
		//not a match 
		return false; 
	}

//create public bools for each card type 
	public boolean isWild() {
		if (value.equals("Wild")&& color.equals(""))
			return true;
		return false;
	}
	
	public boolean isReverse() {
		if (value.equals("Reverse"))
			return true;
		return false;
	}
	
	public boolean isSkip() {
		if (value.equals("Skip"))
			return true; 
		return false;
	}
	
	public boolean isDraw2() {
		if (value.equals("DrawTwo"))
			return true;
		return false;
	}
	
	public boolean isWildDraw4() {
		if (value.equals("WildDrawFour") && color.equals(""))
			return true;
		return false;
	}

	//method to choose the next player based on whether any wild card was played
	public String colorChosen (Player p) {
		int red = 0;
		int yellow = 0; 
		int green = 0; 
		int blue = 0;
		//loops to count how much each color occurs in the player hand
		for (Card c : p.Hand) {
			if (c.color == "Red") {			
				red++;	
			}
			else if (c.color == "Yellow") {
				yellow++;	
			}
			else if (c.color == "Green") {
				green++;	
			}
			else if (c.color == "Blue") {
				blue++;	
			} 
		}
		//if one color had the most occurrence overall the other colors
		//then that color would be chosen 
		if (red>yellow && red>green && red>blue) {
			color = "Red";
		}
		else if (yellow>red && yellow>green && yellow>blue) {
			color = "Yellow";
		}
		else if (green>red && green>yellow && green>blue) {
			color = "Green";
		}
		else if (blue>red && blue>yellow && blue>green) {
			color = "Blue";
		}
		
	//checks if any colors were equal
	//counts the specialty and number cards of each color 
	//if one color had the most number cards, then that color would be chosen 
	//if both colors had the same number cards, then the color with the most amount of 	specialty cards would be chosen
		
//--- STILL HAVE TO CODE: if both colors had the same amount of number and specialty cards, then a randomizer will choose the color---
//---ALSO: if three colors have the same occurrence... so on---
		else if (red == yellow) {
			int redNumbers = 0; 
			int redSpecialty = 0; 
			int yellowNumbers = 0; 
			int yellowSpecialty = 0; 
			for (Card c : p.Hand) {
				if (c.color == "Red") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						redNumbers++; 
					}
					else {
						redSpecialty++; 
					}
				}
				if (c.color == "Yellow") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						yellowNumbers++; 
					}
					else {
						yellowSpecialty++; 
					}
				}
			}
			if (redNumbers>yellowNumbers) {
				color = "Red";
			}
			else if (yellowNumbers>redNumbers){ 
				color = "Yellow";
			}
			else if (redNumbers == yellowNumbers && redSpecialty>yellowSpecialty) {
				color = "Red";
			}
			else if (redNumbers == yellowNumbers && redSpecialty<yellowSpecialty) {
				color = "Yellow";
			}
			/*else if (redNumbers == yellowNumbers && redSpecialty==yellowSpecialty) {
				color = "Red";
			}*/
		}
		else if (red == green) {
			int redNumbers = 0; 
			int redSpecialty = 0; 
			int greenNumbers = 0; 
			int greenSpecialty = 0; 
			for (Card c : p.Hand) {
				if (c.color == "Red") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						redNumbers++; 
					}
					else {
						redSpecialty++; 
					}
				}
				if (c.color == "Green") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						greenNumbers++; 
					}
					else {
						greenSpecialty++; 
					}
				}
			}
			if (redNumbers>greenNumbers) {
				color = "Red";
			}
			else if (greenNumbers>redNumbers){ 
				color = "Green";
			}
			else if (redNumbers == greenNumbers && redSpecialty>greenSpecialty) {
				color = "Red";
			}
			else if (redNumbers == greenNumbers && redSpecialty<greenSpecialty) {
				color = "Green";
			}
			/*else if (redNumbers == greenNumbers && redSpecialty==greenSpecialty) {
				color = "Red";
			}*/
		}
		else if (red == blue) {
			int redNumbers = 0; 
			int redSpecialty = 0; 
			int blueNumbers = 0; 
			int blueSpecialty = 0; 
			for (Card c : p.Hand) {
				if (c.color == "Red") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						redNumbers++; 
					}
					else {
						redSpecialty++; 
					}
				}
				if (c.color == "Blue") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						blueNumbers++; 
					}
					else {
						blueSpecialty++; 
					}
				}
			}
			if (redNumbers>blueNumbers) {
				color = "Red";
			}
			else if (blueNumbers>redNumbers){ 
				color = "Blue";
			}
			else if (redNumbers == blueNumbers && redSpecialty>blueSpecialty) {
				color = "Red";
			}
			else if (redNumbers == blueNumbers && redSpecialty<blueSpecialty) {
				color = "Blue";
			}
			/*else if (redNumbers == blueNumbers && redSpecialty == blueSpecialty) {
				color = "Red";
			}*/
		}
		else if (green == yellow) {
			int greenNumbers = 0; 
			int greenSpecialty = 0; 
			int yellowNumbers = 0; 
			int yellowSpecialty = 0; 
			for (Card c : p.Hand) {
				if (c.color == "Green") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						greenNumbers++; 
					}
					else {
						greenSpecialty++; 
					}
				}
				if (c.color == "Yellow") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						yellowNumbers++; 
					}
					else {
						yellowSpecialty++; 
					}
				}
			}
			if (greenNumbers>yellowNumbers) {
				color = "Green";
			}
			else if (yellowNumbers>greenNumbers){ 
				color = "Yellow";
			}
			else if (yellowNumbers == greenNumbers && yellowSpecialty>greenSpecialty) {
				color = "Yellow";
			}
			else if (yellowNumbers == greenNumbers && yellowSpecialty<greenSpecialty) {
				color = "Green";
			}
			/*else if (yellowNumbers == greenNumbers && yellowSpecialty==greenSpecialty) {
				color = "Yellow";
			}*/
		}
		else if (green == blue) {
			int greenNumbers = 0; 
			int greenSpecialty = 0; 
			int blueNumbers = 0; 
			int blueSpecialty = 0; 
			for (Card c : p.Hand) {
				if (c.color == "Green") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						greenNumbers++; 
					}
					else {
						greenSpecialty++; 
					}
				}
				if (c.color == "Blue") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						blueNumbers++; 
					}
					else {
						blueSpecialty++; 
					}
				}
			}
			if (greenNumbers>blueNumbers) {
				color = "Green";
			}
			else if (greenNumbers<blueNumbers){ 
				color = "Blue";
			}
			else if (blueNumbers == greenNumbers && blueSpecialty>greenSpecialty) {
				color = "Blue";
			}
			else if (blueNumbers == greenNumbers && blueSpecialty<greenSpecialty) {
				color = "Green";
			}
			/*else if (blueNumbers == greenNumbers && blueSpecialty==greenSpecialty) {
				color = "Blue";
			}*/
		}
		else if (yellow == blue) {
			int yellowNumbers = 0; 
			int yellowSpecialty = 0; 
			int blueNumbers = 0; 
			int blueSpecialty = 0; 
			for (Card c : p.Hand) {
				if (c.color == "Yellow") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						yellowNumbers++; 
					}
					else {
						yellowSpecialty++; 
					}
				}
				if (c.color == "Blue") {
					if (c.value == "1" || c.value == "2" || c.value == "3" || 
						c.value == "4"|| c.value == "5"|| c.value == "6"|| 
						c.value == "7" || c.value == "8" || c.value == "9") {
						blueNumbers++; 
					}
					else {	
						blueSpecialty++; 
					}
				}
			}
			if (yellowNumbers>blueNumbers) {
				color = "Yellow";
			}
			else if (blueNumbers>yellowNumbers){ 
				color = "Blue";
			}
			else if (blueNumbers == yellowNumbers && yellowSpecialty>blueSpecialty) {
				color = "Yellow";
			}
			else if (blueNumbers == yellowNumbers && yellowSpecialty<blueSpecialty) {
				color = "Blue";
			}
			/*else if (blueNumbers == yellowNumbers && blueSpecialty==yellowSpecialty) {
				color = "Blue";
			}*/
		}
		else { 
			return "Red"; 
		}
		return color; 
	}
}
