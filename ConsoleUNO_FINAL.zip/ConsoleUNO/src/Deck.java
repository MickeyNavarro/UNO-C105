import java.util.ArrayList;
import java.util.Collections;

// Almicke "Mickey" Navarro
// CST105
// Date: Mar 12, 2018
// This is my own work.

public class Deck {
	private ArrayList <Card> deck;
	
	public Deck() {
		//make the deck 
		deck = new ArrayList<Card>();
		
		String [] colors = { "Red", "Yellow", "Green", "Blue"};
		
		//outer loop = colors
		for (int i = 0; i < 4; i++) {
			for (int n = 0; n < 9; n++) {
				//cards with number value
				deck.add(new Card (Integer.toString(n), colors[i]));
				deck.add(new Card (Integer.toString(n), colors[i]));
			}
			
			//cards with 0 
			deck.add(new Card ("0", colors[i]));
			
			//specialty 
			for (int n = 0; n < 2; n++) {
				deck.add(new Card ("DrawTwo", colors[i]));
				deck.add(new Card ("Skip", colors[i]));
				deck.add(new Card ("Reverse", colors[i]));
			}
			
			//wild 
			deck.add(new Card ("Wild", ""));
			deck.add(new Card ("WildDrawFour", ""));
		}
	}
	
	//gets the value and color from the card class
	public String toString() {
		String str = "";
		for(Card c : deck) {
			str += c + " ";
		}
		return str;
	}
	
	//shuffles deck
	public void shuffle () {
		Collections.shuffle(deck);
	}
	
	//deals a card
	public Card deal() {
		//create a new card
		Card c;
		//get the card (access the card at that position and assigns it to c)
		c = deck.get(deck.size() - 1);
		//remove the card from the deck
		deck.remove(c);
		return c;		
	}
	
	public void addCard(Card c) {
		deck.add(c);
	} 
	
	public boolean isEmpty() {
		return deck.isEmpty();
	}
	
	public int deckSize() {
		int count = 0; 
		for (Card c : deck) {
			count++;
		}
		return count; 
	}
}