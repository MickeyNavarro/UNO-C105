import java.util.ArrayList;
import java.util.Collections;

// Almicke "Mickey" Navarro
// CST105
// Date: Mar 12, 2018
// This is my own work.

public class DiscardPile {

	private ArrayList<Card> discPile;
	
	public DiscardPile() {
		discPile = new ArrayList<Card>(); 
	}
	
	//return top card without removing it
	public Card getTopCard() {
		if (discPile.isEmpty())
			return null;
		return discPile.get(discPile.size() - 1);
	}
	
	//add card c to the discard pile
	public void setTopCard(Card c) {
		discPile.add(c);
	}
	
	//check if empty
	public boolean isEmpty() {
		return discPile.isEmpty();
	}
	
	//create a deck 
	public static Deck myDeck = new Deck(); 
	
	//shuffle discard pile; if deck is empty, add it to the deck
	public Deck reshuffle() {
		Collections.shuffle(discPile);
		for (int i = 0; i < discPile.size(); i++) {
			myDeck.addCard(discPile.get(discPile.size() - 1));
		}
		return myDeck; 
	}
}