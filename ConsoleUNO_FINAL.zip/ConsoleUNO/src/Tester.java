import java.util.ArrayList;

// Almicke "Mickey" Navarro
// CST105
// Date: Mar 12, 2018
// This is my own work with the help of Emily Quevedo & Josh Salvador

// ---MILESTONE 4---

public class Tester {

	public static int playerTurn = 0;
	public static int revFactor = 1; 
	public static ArrayList<Player> players = new ArrayList<Player>(); 
	public static Deck myDeck = new Deck(); 
	public static DiscardPile discPile = new DiscardPile(); 
	public static boolean specialCardPlayed = false; 
	
	public static void main(String[] args) {
		System.out.println("Begin game!" + "\n");

		//make deck - no need to make deck due to deck being a public static Deck 
		//Deck myDeck = new Deck ();
		myDeck.shuffle();
				
		//make 4 players 
		Player p1 = new Player("Kylie"),
				p2 = new Player("Chael"),
				p3 = new Player("Nate"),
				p4 = new Player("MJ");	
		
		//add players to arraylist to be easily accessible
		players.add(p1);
		players.add(p2);
		players.add(p3);
		players.add(p4);
		
		//deal 7 cards to each player 
		for (int i = 0; i < 7; i++) {
			players.get(0).takeCard(myDeck.deal());
			players.get(1).takeCard(myDeck.deal());
			players.get(2).takeCard(myDeck.deal());
			players.get(3).takeCard(myDeck.deal());
		}
	
		//initialize the discard pile 
		discPile.setTopCard(myDeck.deal()); 
		
		//output player hands and top card
		System.out.println(players.get(0).getName() + ": " + players.get(0));
		System.out.println(players.get(1).getName() + ": " + players.get(1));
		System.out.println(players.get(2).getName() + ": " + players.get(2));
		System.out.println(players.get(3).getName() + ": " + players.get(3));
		System.out.println("Top Card: " + discPile.getTopCard());
		//System.out.println("Deck Size: " + myDeck.deckSize());
		
		
		//do-while loop will allow the plays to continue until there is no winner 
		//within the loop, it checks if the deck is empty
		//---if yes, the play must stop and re-shuffle the discard pile and add to the deck
		//---if no, the players do their turn
		do {
			if (!myDeck.isEmpty()) {
				playTurn(); 
			}
			else {
				System.out.println("Whoops! Deck is empty!");
				discPile.reshuffle(); 
				myDeck = discPile.reshuffle();
				System.out.println("Play can continue!");
			} 
			
		} while (players.get(playerTurn).winner() == false); 
	}
	
	/*Card cardPlayed = players.get(playerTurn).playCard(myDeck.deal().hashCode(), myDeck.deal());
	int b = p1.hashCode(cardPlayed);

	if (cardPlayed.isMatch(discPile.setTopCard(cardPlayed)) == true) {
		p1.playCard( b, cardPlayed);
		discPile.setTopCard(cardPlayed);
	}
	else {
		Card cardDealt = myDeck.deal();
		p1.takeCard(cardDealt);
		if (discPile.getTopCard().isMatch(cardDealt) == true) {
			p1.playCard( b, c);
			discPile.setTopCard(c);
		}
	}*/	

//method will also fulfill what each card must make the players do 
	public static void setNextPlayer( Card c ) 
	{
		if (c.isWild() == true) {
			//reset the bool to allow special cards to be played
			specialCardPlayed = false; 
			//output 
			System.out.println("Wild Card played!");
			//choose the color 
			c.colorChosen(players.get(playerTurn)); 
			//output color chosen 
			System.out.println("Color chosen: " + c.color);
			//update the card to have a color
			Card wild = new Card("Wild", c.color);
			//add the new card to discard pile 
			discPile.setTopCard(wild);
			//update to next player
			playerTurn = (playerTurn + revFactor + 4) % 4;
			
		}
		else if (c.isWildDraw4() == true) {
			//reset the bool to allow special cards to be played
			specialCardPlayed = false; 
			//output 
			System.out.println("Wild Draw 4 Card played!");
			//choose the color 
			c.colorChosen(players.get(playerTurn)); 
			//output color
			System.out.println("Color chosen: " + c.color);
			//update wild card to have a color 
			Card wildFour = new Card("WildDrawFour", c.color);
			//add the new card to discard pile 
			discPile.setTopCard(wildFour);
			//update to next player (skipped player)
			playerTurn = (playerTurn + revFactor + 4) % 4;
			//make the skipped player draw 4 cards
			players.get(playerTurn).takeCard(myDeck.deal());
			players.get(playerTurn).takeCard(myDeck.deal());
			players.get(playerTurn).takeCard(myDeck.deal());
			players.get(playerTurn).takeCard(myDeck.deal());
			//output
			System.out.println(players.get(playerTurn).getName() + " has drawn 4 cards!");
			//update to next player once more, because the skipped player who gets the cards may not fulfill a turn 
			playerTurn = (playerTurn + revFactor + 4) % 4;
			
		}
		
		else if (c.isReverse() == true && specialCardPlayed == false){
			//update the reverse factor to change the order of the game 
			revFactor = revFactor * -1; 
			//update to next player
			playerTurn = (playerTurn + revFactor + 4) % 4;
			//output
			System.out.println("Reverse Card played! Order has been reversed!");
			//change bool to true to avoid this card from changing the play order once played
			specialCardPlayed = true; 
		}
		
		else if (c.isDraw2() == true && specialCardPlayed == false) {
			//update to next player (skipped player)
			playerTurn = (playerTurn + revFactor + 4) % 4;
			//make the skipped player draw 4 cards
			players.get(playerTurn).takeCard(myDeck.deal());
			players.get(playerTurn).takeCard(myDeck.deal());
			//output
			System.out.println("Draw 2 Card played! " + players.get(playerTurn).getName() + " has drawn 2 cards!");
			//update to next player once more, because the skipped player who gets the cards may not fulfill a turn 
			playerTurn = (playerTurn + revFactor + 4) % 4;
			//change bool to true to avoid this card redoing its actions once played 
			specialCardPlayed = true; 
		}
		else if (c.isSkip() == true && specialCardPlayed == false) {
			//update to next player (skipped player)
			playerTurn = (playerTurn + revFactor + 4) % 4;
			//output 
			System.out.println("Skip Card played! " + players.get(playerTurn).getName() + " has been skipped!");
			//no action is taken from the skipped player so update to next player 
			playerTurn = (playerTurn + revFactor + 4) % 4;
			//change bool to true to avoid this card from changing the play order once played
			specialCardPlayed = true; 
		}
		
		else {
			//reset the bool to allow special cards to be played
			specialCardPlayed = false; 
			//update to next player
			playerTurn = (playerTurn + revFactor + 4) % 4;
		}
		System.out.println("Deck Size: " + myDeck.deckSize());
	}
	
	public static void playTurn() 
	{	//create a new card
		Card cardPlayed = players.get(playerTurn).playCard(players.get(playerTurn), discPile.getTopCard());	
		
		//check if the card returned was a match to the top card, or not returned null
		if (cardPlayed != null) {
			//output
			System.out.println(players.get(playerTurn).getName() + " played: " + cardPlayed);
			//set the new top card as the card that was played
			discPile.setTopCard(cardPlayed); 
			//check if uno
			if (players.get(playerTurn).uno() == true) {
				System.out.println(players.get(playerTurn).getName() + " has called UNO!");
			}	
			//check if winner
			else if (players.get(playerTurn).winner() == true) {
				System.out.println("\nWINNER WINNER! CHICKEN DINNER!");
				System.out.println(players.get(playerTurn).getName() + " has won!");
				//exit game 
				System.exit(0);
			}
			//update player based on the card just played
			setNextPlayer(cardPlayed);
			//output 
			System.out.println("");
			System.out.println(players.get(0).getName() + ": " + players.get(0));
			System.out.println(players.get(1).getName() + ": " + players.get(1));
			System.out.println(players.get(2).getName() + ": " + players.get(2));
			System.out.println(players.get(3).getName() + ": " + players.get(3));
			System.out.println("Top Card: " + discPile.getTopCard());
		}
		//check if the card returned was not a match to the top card, or returned null:
		else if (cardPlayed == null){
			//deal a new card
			Card cardDealt = myDeck.deal(); 
			//make player get the new card 
			players.get(playerTurn).takeCard(cardDealt);
			//output 
			System.out.println("Card was dealt to " + players.get(playerTurn).getName());

			//check if match
			if (cardDealt.isMatch(discPile.getTopCard()) == true) {
				//play the new card
				players.get(playerTurn).playCard(players.get(playerTurn), cardDealt);
				//set the new top card as the card that was played
				discPile.setTopCard(cardDealt); 
				//output
				System.out.println(players.get(playerTurn).getName() + " played: " + cardDealt );
				//check if uno
				if (players.get(playerTurn).uno() == true) {
					System.out.println(players.get(playerTurn).getName() + " has called UNO!");
				}
				//update player based on the card just played
				setNextPlayer(cardDealt);
				System.out.println("");
				System.out.println(players.get(0).getName() + ": " + players.get(0));
				System.out.println(players.get(1).getName() + ": " + players.get(1));
				System.out.println(players.get(2).getName() + ": " + players.get(2));
				System.out.println(players.get(3).getName() + ": " + players.get(3));
				System.out.println("Top Card: " + discPile.getTopCard());
			}
			else { 
				//output that next player must go 
				System.out.println(players.get(playerTurn).getName() + " had no matches!");
				//update player based on the top card 
				setNextPlayer(discPile.getTopCard());
				System.out.println("");
				System.out.println(players.get(0).getName() + ": " + players.get(0));
				System.out.println(players.get(1).getName() + ": " + players.get(1));
				System.out.println(players.get(2).getName() + ": " + players.get(2));
				System.out.println(players.get(3).getName() + ": " + players.get(3));
				System.out.println("Top Card: " + discPile.getTopCard());
				
			}
		}
	}		
}