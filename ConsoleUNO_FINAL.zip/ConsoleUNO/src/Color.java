// Almicke "Mickey" Navarro
// CST105
// Date:Apr 6, 2018
// This is my own work.

public class Color {
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	
	
	String Red = ANSI_RED + "Red"; 
	String Yellow = ANSI_YELLOW + "Yellow"; 
	String Green = ANSI_GREEN + "Green"; 
	String Blue = ANSI_BLUE + "Blue"; 
}
